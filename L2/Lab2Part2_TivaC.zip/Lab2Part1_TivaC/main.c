#include <stdint.h>
#include "SysTick.h"
#include "PLL.h"
#include "tm4c123gh6pm.h"


void main(void){

  PLL_Init(Bus80MHz);  // set system clock to 80 MHz

}
